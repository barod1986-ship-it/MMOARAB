from __future__ import annotations

import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

import pytest  # noqa: E402

raise SystemExit(pytest.main(["-q", str(ENGINE_ROOT / "tests")]))
